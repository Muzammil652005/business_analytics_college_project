import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pickle, os
from sklearn.linear_model import LinearRegression
from auth import login
from pdf_report import generate_pdf

# ================= PAGE CONFIG =================
st.set_page_config(page_title="Business Analytics", layout="wide")

# ================= LOGIN =================
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    st.title("🔐 Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        role = login(username, password)
        if role:
            st.session_state.logged_in = True
            st.session_state.role = role
            st.rerun()   # ✅ FIXED (was experimental_rerun)
        else:
            st.error("Invalid credentials")
    st.stop()

# ================= THEME SWITCH =================
theme = st.sidebar.radio("🎨 Theme Mode", ["Light", "Dark"])

if theme == "Dark":
    st.markdown("""
    <style>
    body { background-color: #0e1117; color: white; }
    </style>
    """, unsafe_allow_html=True)

# ================= SIDEBAR =================
st.sidebar.title("📂 Options")
uploaded_file = st.sidebar.file_uploader("Upload CSV", type="csv")

# ================= LOAD DATA =================
if uploaded_file:
    df = pd.read_csv(uploaded_file)
else:
    df = pd.read_csv("data/business_data.csv")

# ================= TITLE =================
st.title("📊 Data-Driven Business Insights")
st.subheader("Descriptive & Predictive Analytics Dashboard")

# ================= KPI =================
c1, c2, c3 = st.columns(3)
c1.metric("Avg Sales", f"{df['Sales'].mean():.2f}")
c2.metric("Max Sales", df["Sales"].max())
c3.metric("Total Customers", df["Customers"].sum())

# ================= EDA =================
st.header("📄 Dataset Preview")
st.dataframe(df)

st.header("📊 Descriptive Analytics")
st.write(df.describe())

# ================= HEATMAP =================
st.header("🔥 Correlation Heatmap")
fig, ax = plt.subplots()
sns.heatmap(df.corr(), annot=True, cmap="coolwarm", ax=ax)
st.pyplot(fig)

# ================= MODEL =================
X = df[["Advertising", "Customers", "Discount"]]
y = df["Sales"]

model = LinearRegression()
model.fit(X, y)

os.makedirs("model", exist_ok=True)
with open("model/sales_model.pkl", "wb") as f:
    pickle.dump(model, f)

# ================= PREDICTION =================
st.header("🤖 Predictive Analytics")

ad = st.slider("Advertising Spend", 5, 50, 20)
cust = st.slider("Customers", 50, 210, 100)
disc = st.slider("Discount (%)", 2, 20, 8)

prediction = model.predict([[ad, cust, disc]])[0]
st.success(f"💰 Predicted Sales: ₹ {prediction:.2f}")

# ================= PDF DOWNLOAD =================
pdf_file = generate_pdf(prediction)
with open(pdf_file, "rb") as f:
    st.download_button(
        "📥 Download Prediction Report (PDF)",
        f,
        file_name="prediction_report.pdf"
    )

# ================= FOOTER =================
st.markdown("""
---
<center>
<b>Academic Business Analytics Project</b><br>
Python • Streamlit • Machine Learning
</center>
""", unsafe_allow_html=True)
